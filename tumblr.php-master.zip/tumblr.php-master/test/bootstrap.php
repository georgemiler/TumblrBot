<?php

date_default_timezone_set('America/New_York');

require_once 'vendor/autoload.php';
require_once 'test/TumblrTest.php';

define('API_KEY', 'the testing consumer key');
